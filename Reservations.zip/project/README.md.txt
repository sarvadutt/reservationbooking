                                                          BUSS TICKET BOOKING
==>  Video Demo :  < https://drive.google.com/file/d/1lfWzInrUtYb5K2n0dxCKYm9mEFdYNY9P/view?usp=sharing >
==>  Description:
                 
                 Hello every one. By using simple c command we have made a buss ticket booking application.
                 this application contains username and password before going through it. It is pre registerd one
                 A bus reservation system is a mobile or web software solution designed to provide customers with 
                 a personalized easy-to-utilize user experience for booking and purchasing tickets online. 
                 it stores customers’ personal data records, scheduled routes, frequent trips, drop points, and other information.

                 You can implement real-time seat availability, multiple payment gateways, offer seat map functionality, and other features.
                 A transport booking eliminates human factor risks and improves conversion rates for your business
               
                
                      username   finallproject
                      password   cs50

                This application is command based offline project.Where user need to login using given username and password (pre defined)
                 when user login using given crediantials he/her now able to go through program.
                 User now gets displayed all avialble options to use the program
                  1. View bus list
                  2. Tickets booking
                  3. Cancelation
                  4. Your status
                  5. Exit
                  When we go  to first option that is (View bus list) we get list of all options are there i.e.. Busses Name
                  User need to select the option When user select the option an another promt will open to select the seats by 
                  user wish. User can also able to find seats occupied by another passengers through name.

                  User can Now able to cancel the ticket BY using thied option. User need to follow the instructions and follow the 
                  promt to cancel completely
                  
                 User can able to view his status of refund and vaccancies and occupied seats by selecting fourth option 

                 At last after completing using this program User can get out of command promt by selecting fifth option.

               
                 Now 
                 Topics used to desing the application

1. for loops to get the input from passengers for no tickets needed
2. files to store the data after competion of booking 
3. functions to call the fuctions when ever needed
4.arrays to store the data in it (names of the passengers )
5. switch to go into particular option needed
6. if else to check the false input.
                 

                 we have used function which is already declared befor main function ,also used files which generates new file 
                 to store data 
                 types of files 
                  
            ==> Rs is file used to know the remaing seats in a particular buss where we get Rs1,Rs2.. which indicates the buss no followed 
                 to it.
            ==> number is a file where we get no of seats booked in that particular bus 
            ==> status heir we will know the name of the person booked the buss 

            while booking the buss the applicarion askes how many seats would like to book 
                 (( for this we have used for loop )) 
            after selecting it askes you to select seat no with preference 
ser can also able to find seats occupied by another passengers through name.

                  User can Now able to cancel the ticket BY using thied option. User need to follow the instructions and follow the 
                  promt to cancel completely .User can able to view his status of refund and vaccancies and occupied seats by selecting fourth option 
                  At last after completing using this program User can get out of command promt by selecting fifth option.
                  then after name to fill the empty slot with your name
                  we can also view the seats and emptys in the buss
                  they is cancelation also avialabe in it .
                  at last when we exit they will be conclusion page with customr support email address.
             


                                                                                                        Credits 
                                                                            for completing the project i have taken ideas form
                                                                            my siblings & for sorting the errors i have utilizes internet.
                                             Thanks you..........  

  
            
                

